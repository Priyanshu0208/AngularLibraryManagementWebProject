import { Component } from '@angular/core';
import { GetBooksService } from './services/get-books.service';
import { AuthServiceService } from './services/auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  isLoggedIn = false;
  constructor(
    private getBooksService: GetBooksService,
    private authServiceService: AuthServiceService
  ) {
    this.getBooksService.getBooks();
    //this.authServiceService.getIsLoggedIn$().subscribe((status) => {
    //this.appserviceService.isLoggedIn = status;
    //});
  }

  logout() {
    this.authServiceService.logout();
  }
}
