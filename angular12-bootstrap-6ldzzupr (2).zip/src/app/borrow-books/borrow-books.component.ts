import { Component, OnInit } from '@angular/core';
import { GetBooksService } from '../services/get-books.service';

@Component({
  selector: 'app-borrow-books',
  templateUrl: './borrow-books.component.html',
  styleUrls: ['./borrow-books.component.css'],
})
export class BorrowBooksComponent implements OnInit {
  borrowBookList;
  error;
  constructor(private getBooksService: GetBooksService) {}

  ngOnInit() {
    this.getBooksService.borrowedBooks$.subscribe((data) => {
      this.borrowBookList = data;
      this.error = 'No books borrowed';
    });
  }
  issueBooks(borrowBookList) {
    //we can make here api call to store user issue books
  }
}
