import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AppserviceService {
  availablebooks;
  isLoggedIn;
  constructor() {}
  setAvailableBooks(books) {
    this.availablebooks = books;
    //console.log('setAvailableBooks = ' + this.availablebooks);
  }
  getAvailableBooks() {
   // console.log('getAvailableBooks = ' + this.availablebooks);
    return this.availablebooks;
  }
}
