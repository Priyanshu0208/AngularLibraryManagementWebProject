import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { AppserviceService } from './appservice.service';
@Injectable()
export class AuthServiceService {
  private isLoggedInSubject = new BehaviorSubject<boolean>(this.hasToken());
  constructor(private appserviceService: AppserviceService) {}
  login(email: string, password: string): Observable<boolean> {
    if (email === 'priyanshu0208@gmail.com' && password === '123') {
      localStorage.setItem('tokens', 'fake-jwt');
      this.isLoggedInSubject.next(true);
      return of(true);
    }
    return of(false);
  }

  logout(): void {
    localStorage.removeItem('tokens');
    this.appserviceService.isLoggedIn = false;
    this.isLoggedInSubject.next(false);
  }

  isAuthenticated(): boolean {
    return this.isLoggedInSubject.value;
  }

  getIsLoggedIn$(): Observable<boolean> {
    return this.isLoggedInSubject.asObservable();
  }

  private hasToken(): boolean {
    return !!localStorage.getItem('tokens');
  }
}
