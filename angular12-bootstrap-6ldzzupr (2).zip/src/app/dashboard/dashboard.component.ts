import { Component, OnInit } from '@angular/core';
import { GetBooksService } from '../services/get-books.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  availableBooksList;
  borrowBookList;
  numOfBookIssued = 0;
  error = '';
  constructor(
    private getBooksService: GetBooksService
  ) {}
  ngOnInit() {
    this.getBooksService.loadBooks();
    this.getBooksService.availableBooks$.subscribe((data) => {
      this.availableBooksList = data;
    });
    this.getBooksService.borrowedBooks$.subscribe((data) => {
      this.borrowBookList = data;
    });
  }
  borrowBook(id: number) {
    this.numOfBookIssued++;
    console.log('this.numOfBookIssued=' + this.numOfBookIssued);
    if (this.numOfBookIssued < 3) {
      this.getBooksService.borrowBook(id);
    } else {
      this.error = 'Reahced daily maximum limit';
    }
  }
}
