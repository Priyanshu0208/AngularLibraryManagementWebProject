import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetBooksService } from '../services/get-books.service';
import { AuthServiceService } from '../services/auth-service.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {
  availableBooksList;
  borrowBookList;
  error1;
  constructor(
    private getBooksService: GetBooksService,
    private router: Router,
    private authServiceService: AuthServiceService
  ) {}

  ngOnInit() {
    this.getBooksService.loadBooks();
    this.getBooksService.availableBooks$.subscribe((data) => {
      this.availableBooksList = data;
    });
    this.getBooksService.borrowedBooks$.subscribe((data) => {
      this.borrowBookList = data;
      this.error1 = 'No books borrowed';
    });
  }
  addBooks() {
    this.router.navigate(['/addBooks']);
  }
  borrowedBooks() {
    this.router.navigate(['/borrowBooks']);
  }
  logoutadmin() {
    this.authServiceService.logout();
    this.router.navigate(['/login']);
  }
}
