import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-add-books',
  templateUrl: './add-books.component.html',
  styleUrls: ['./add-books.component.css'],
})
export class AddBooksComponent implements OnInit {
  addBookForm: FormGroup;
  isSubmitted = false;
  formError = false;
  constructor(private fb: FormBuilder, private http: HttpClient) {}
  // "h5": "The Great Gatsby",
  // "p": "by F. Scott Fitzgerald",
  // "small":
  ngOnInit() {
    this.addBookForm = this.fb.group({
      title: new FormControl('', Validators.required),
      author: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
    });
  }
  onSubmit() {
    console.log(this.addBookForm.value);
    //make API call here to save new book
    //this.http.put(`${this.baseUrl}/${id}`, updatedData);
  }
}
